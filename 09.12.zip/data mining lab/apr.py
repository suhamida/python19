import numpy as np
import pandas as pd
from aproiry import apriori

book_data=pd.read_csv('C:\\Users\\88017\\PycharmProjects\\final\\data mining lab\\Book1.csv',header=None)
print(book_data)

#converting dataframe into list
items=[]
for i in range(0, 22):
 items.append([str(book_data.values[i,j]) for j in range(0,6)])
#generating apriori model
final_rule=apriori(items,min_support=0.5,min_confidence=0.7,min_lift=1.2,min_length=2)
#grouping all the rules into a list
final_results=list(final_rule)
print(final_results)